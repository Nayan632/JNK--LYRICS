import loader from './loader.svg';
import logo from './macLogo.svg';

export {
  logo,
  loader,
};
